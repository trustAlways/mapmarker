package fare.calculate.demo.com.googlemapfordist;

import com.google.android.gms.maps.model.LatLng;

public class Constants {

    //Map LatLong points
    public static LatLng POINT_DEST = null;
}
