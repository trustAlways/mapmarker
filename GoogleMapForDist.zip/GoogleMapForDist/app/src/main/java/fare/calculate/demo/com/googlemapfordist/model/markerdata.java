package fare.calculate.demo.com.googlemapfordist.model;

import com.google.android.gms.maps.model.LatLng;

public class markerdata
{
    private final LatLng mPosition;
    private String mTitle;
    String id;
    private  String mSnippet;

    public markerdata(double lat, double lng) {
        mPosition = new LatLng(lat, lng);
    }

    public markerdata(String id,double lat, double lng, String title, String snippet) {
        this.id=id;
        mPosition = new LatLng(lat, lng);
        mTitle = title;
        mSnippet = snippet;
    }

    public LatLng getmPosition() {
        return mPosition;
    }

    public String getmTitle() {
        return mTitle;
    }

    public void setmTitle(String mTitle) {
        this.mTitle = mTitle;
    }

    public String getmSnippet() {
        return mSnippet;
    }

    public void setmSnippet(String mSnippet) {
        this.mSnippet = mSnippet;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
