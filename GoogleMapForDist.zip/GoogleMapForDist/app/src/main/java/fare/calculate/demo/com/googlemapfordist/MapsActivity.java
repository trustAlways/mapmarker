package fare.calculate.demo.com.googlemapfordist;

import android.Manifest;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;


import com.directions.route.AbstractRouting;
import com.directions.route.Route;
import com.directions.route.RouteException;
import com.directions.route.Routing;
import com.directions.route.RoutingListener;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import fare.calculate.demo.com.googlemapfordist.model.markerdata;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback, LocationListener, GoogleMap.OnMarkerClickListener,RoutingListener {

    private GoogleMap mMap;

    private LocationManager locationManager = null;
    private AutoCompleteTextView txtDistance, txtTime;
    ImageView send,refresh,cutImage,user_img;
    Dialog mydialog;

    TextView tv_Stockiest_name,user_location,tv_distance_kms;
    //Global UI Map markers
    private Marker currentMarker = null;
    private Marker destMarker = null;
    private LatLng currentLatLng = null;
    private LatLng destLatLng = null;
    private ArrayList<markerdata> latlong;
    ArrayList<LatLng> markerPoints;
    private Polyline line = null;
    ProgressBar progressBar;
    LatLng p1 = null;
    LatLng p2 = null;
    String f1,f2;
    //Global flags
    private boolean firstRefresh = true;
    private int[] logos = {
            R.drawable.auto_one, R.drawable.auto_two, R.drawable.auto_three, R.drawable.auto_four, R.drawable.auto_five,R.drawable.auto_six,
            R.drawable.auto_seven
            ,R.drawable.auto_eight,R.drawable.auto_three,R.drawable.auto_eight};
    private String[] names = {"Abim","Adjumani","Alebtong","Amolatar","Amuria","Amuru",
            "Tim Cook","Apac","Arua","Guptil"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        if (ContextCompat.checkSelfPermission(this,
                android.Manifest.permission.ACCESS_FINE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) ==
                        PackageManager.PERMISSION_GRANTED) {
            // Permission already Granted
            //Do your work here
            //Perform operations here only which requires permission
            // Initializing
        markerPoints = new ArrayList<LatLng>();

        Constants.POINT_DEST = new LatLng(22.7533, 75.8937); //Lonavala destination.
        // Add cluster items (markers) to the cluster manager.
        addItems();
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        txtDistance = (AutoCompleteTextView) findViewById(R.id.start);
        txtTime = (AutoCompleteTextView) findViewById(R.id.destination);
        send = (ImageView)findViewById(R.id.send);
        refresh = (ImageView)findViewById(R.id.refresh);

        progressBar = (ProgressBar)findViewById(R.id.pb);

        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                 p1 = null;
                 p2 = null;
                 mMap.clear();
              if (!txtDistance.getText().toString().equalsIgnoreCase(""))
              {
                  progressBar.setVisibility(View.VISIBLE);
                  String add1 = txtDistance.getText().toString().trim();
                  getLocationFromAddress(MapsActivity.this,add1);
              }
              else
              {
                  progressBar.setVisibility(View.GONE);
                  txtDistance.setError("Enter start location..");
              }

             Toast.makeText(MapsActivity.this, "Fetching Route", Toast.LENGTH_SHORT).show();
            }
        });

        refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MapsActivity.this,MapsActivity.class));
            }
        });

        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
        }

    }

    private void addItems()
    {
        latlong = new ArrayList<>();
        // Set some lat/lng coordinates to start with.
        double lat = 0.3476;
        double lng = 32.5825;

        // Add ten cluster items in close proximity, for purposes of this example.
        for (int i = 0; i < 10; i++) {
            double offset = i / 1000d;
            System.out.println("offset "+offset);
            lat = lat + offset;
            lng = lng + offset;
            String id = String.valueOf(i);
            String title = "this is your address";
            String snippet = "and this is the snippet.";

            double precision =  Math.pow(10, 6);

            double new_Latitude = ((int)(precision * lat))/precision;
            double new_Longitude = ((int)(precision * lng))/precision;

            String add = getAddressFromCoordinates(this,new_Latitude,new_Longitude);

            markerdata offsetItem = new markerdata(id,new_Latitude, new_Longitude,title,add);
            latlong.add(offsetItem);
        }
    }


    @Override
    protected void onResume() {
        super.onResume();
        firstRefresh = true;
        //Ensure the GPS is ON and location permission enabled for the application.
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);
        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 5000, 0, this);
    }

    @Override
    protected void onPause() {
        if (locationManager != null) {
            //Check needed in case of  API level 23.

            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED) {
            }
            try {
                locationManager.removeUpdates(this);
            } catch (Exception e) {
            }
        }
        locationManager = null;
        super.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    public void onLocationChanged(Location location)
    {
        double lat = location.getLatitude();
        double lng = location.getLongitude();
        double precision =  Math.pow(10, 6);
        double new_Latitude = ((int)(precision * lat))/precision;
        double new_Longitude = ((int)(precision * lng))/precision;
        currentLatLng = new LatLng(new_Latitude, new_Longitude);

        if(firstRefresh)
        {
            //Add Start Marker.
            for (markerdata latLng : latlong)
            {
                System.out.println("positionss -- "+ latLng.getmPosition());
                currentMarker = mMap.addMarker(new MarkerOptions().position(latLng.getmPosition()).title(latLng.getId()).snippet(latLng.getmSnippet()));//.icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_send_grey600_48dp)));

            }
            mMap.moveCamera(CameraUpdateFactory.newLatLng(latlong.get(0).getmPosition()));
            mMap.animateCamera(CameraUpdateFactory.zoomTo(15));
                          //firstRefresh = false;
            //destMarker = mMap.addMarker(new MarkerOptions().position(Constants.POINT_DEST).title("Destination"));//.icon(BitmapDescriptorFactory.fromResource(R.drawable.location)));

            firstRefresh = false;

            // getRoutingPath(p1, p2);
        }
        else
        {
            currentMarker.setPosition(currentLatLng);
        }
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {}

    @Override
    public void onProviderEnabled(String provider) {}

    @Override
    public void onProviderDisabled(String provider) {}


            /**
             * Manipulates the map once available.
             * This callback is triggered when the map is ready to be used.
             * This is where we can add markers or lines, add listeners or move the camera. In this case,
             * we just add a marker near Sydney, Australia.
             * If Google Play services is not installed on the device, the user will be prompted to install
             * it inside the SupportMapFragment. This method will only be triggered once the user has
             * installed Google Play services and returned to the app.
             */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        mMap.setMyLocationEnabled(true);

        //mMap.getUiSettings().setZoomControlsEnabled(true);
        mMap.getUiSettings().setCompassEnabled(true);
        mMap.getUiSettings().setAllGesturesEnabled(true);
        mMap.setOnMarkerClickListener(this);
    }


    @Override
    public boolean onMarkerClick(Marker marker)
    {
        double lat = marker.getPosition().latitude;
        double lng = marker.getPosition().longitude;
        destLatLng = new LatLng(lat, lng);

       // getRoutingPath(currentLatLng,destLatLng);
        int distance = CalculationByDistance(currentLatLng,destLatLng);

        String id = marker.getTitle();
        String address =  marker.getSnippet();

        Myalertdialog(id,address,distance);
        return false;
    }

    private String getAddressFromCoordinates(MapsActivity mapsActivity, double latitude, double longitude)
    {
        Geocoder geocoder;
        List<Address> addresses;
        geocoder = new Geocoder(this, Locale.getDefault());

        try {
            addresses = geocoder.getFromLocation(latitude, longitude, 1); // Here 1 represent max location result to returned, by documents it recommended 1 to 5


        String address = addresses.get(0).getAddressLine(0); // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex()
        String city = addresses.get(0).getLocality();
        String state = addresses.get(0).getAdminArea();
        String country = addresses.get(0).getCountryName();
        String postalCode = addresses.get(0).getPostalCode();
        String knownName = addresses.get(0).getFeatureName();

        return address;

        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }


    public LatLng getLocationFromAddress(Context context, String strAddress) {

        Geocoder coder = new Geocoder(context);
        List<Address> address;

        try {
            // May throw an IOException
            address = coder.getFromLocationName(strAddress, 5);
            if (address == null) {
                return null;
            }
            System.out.println("add -- +=" + address);
            Address location = address.get(0);
            f1 = address.get(0).getFeatureName();

            p1 = new LatLng(location.getLatitude(), location.getLongitude() );

            if (p1!=null)
            {
                if (!txtTime.getText().toString().trim().equalsIgnoreCase(""))
                {
                    System.out.println("add --p1 +=" + p1);

                    progressBar.setVisibility(View.VISIBLE);
                    String add2 = txtTime.getText().toString().trim();
                    getLocationFromAddress1(MapsActivity.this,add2);
                }
                else
                {
                    progressBar.setVisibility(View.GONE);
                    txtTime.setError("Enter end location..");
                }

            }

        } catch (IOException ex) {

            ex.printStackTrace();
        }

        return p1;
    }

    public LatLng getLocationFromAddress1(Context context, String strAddress) {

        Geocoder coder = new Geocoder(context);
        List<Address> address2;

        try {
            // May throw an IOException
            address2 = coder.getFromLocationName(strAddress, 5);
            if (address2 == null) {
                return null;
            }
            System.out.println("add -- +=" + address2);
            Address location = address2.get(0);
             f2 = address2.get(0).getFeatureName();
             p2 = new LatLng(location.getLatitude(), location.getLongitude() );

            if (p2!=null)
            {
                getRoutingPath(p1,p2);
            }

        } catch (IOException ex) {

            ex.printStackTrace();
        }

        return p1;
    }





    private void getRoutingPath(LatLng la, LatLng lo)
    {
        try
        {
            System.out.println("currentlatlng --- p1 "+p1);
            System.out.println("currentlatlng p2 --- "+p2);

            p1 = la;
            p2 = lo;
            //Do Routing
/*
            Routing routing = new Routing.Builder()
                    .travelMode(Routing.TravelMode.DRIVING)
                    .withListener(this)
                    .waypoints(currentLatLng, Constants.POINT_DEST)
                    .key("AIzaSyCGEf3p343e23XcQaWlAkMGpVoyNivFqSQ")
                    .build();
            routing.execute();
*/

            Routing routing = new Routing.Builder()
                    .travelMode(AbstractRouting.TravelMode.DRIVING)
                    .withListener(this)
                    .alternativeRoutes(true)
                    .waypoints(p1, p2)
                    .key("AIzaSyB3cVrZfV1PniRpuzYrO92YdP6-a2H7n0o")
                    .build();
            routing.execute();
            System.out.println("--------------"+routing.toString());

        }
        catch (Exception e)
        {
            System.out.println("--------------"+e.getMessage());
            Toast.makeText(MapsActivity.this, "Unable to Route"+e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRoutingFailure(RouteException e) {

        System.out.println("--------------"+e.getMessage());

        int distance = CalculationByDistance(p1, p2);
        //txtDistance.setText(distance+ "km" + "Total");
        progressBar.setVisibility(View.GONE);

        /*showalertDialog(distance);

        //Add Start Marker.
        currentMarker = mMap.addMarker(new MarkerOptions().position(p1).title(f1));//.icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_send_grey600_48dp)));
        firstRefresh = false;
        destMarker = mMap.addMarker(new MarkerOptions().position(p2).title(f2));//.icon(BitmapDescriptorFactory.fromResource(R.drawable.location)));

        mMap.moveCamera(CameraUpdateFactory.newLatLng(p2));

        mMap.addPolyline(new PolylineOptions().color(R.color.red).add(p1,p2));

        mMap.animateCamera(CameraUpdateFactory.zoomTo(15));*/
       // Adding new item to the ArrayList
        markerPoints.add(p1);
        markerPoints.add(p2);
        // Getting URL to the Google Directions API
        String url = getDirectionsUrl(p1, p2);
        Log.d("Background Task---",url);

        DownloadTask downloadTask = new DownloadTask();
        // Start downloading json data from Google Directions API
        downloadTask.execute(url);

    }



    @Override
    public void onRoutingStart() {

    }

    @Override
    public void onRoutingSuccess(ArrayList<Route> list, int i) {
        try
        {
            //Get all points and plot the polyLine route.
            List<LatLng> listPoints = list.get(0).getPoints();
            PolylineOptions options = new PolylineOptions().width(5).color(Color.BLUE).geodesic(true);
            Iterator<LatLng> iterator = listPoints.iterator();
            while(iterator.hasNext())
            {
                LatLng data = iterator.next();
                options.add(data);
            }

            //If line not null then remove old polyline routing.
            if(line != null)
            {
                line.remove();
            }
            line = mMap.addPolyline(options);

            //Show distance and duration.
            txtDistance.setText("Distance: " + list.get(0).getDistanceText());
            txtTime.setText("Duration: " + list.get(0).getDurationText());

            //Focus on map bounds
            mMap.moveCamera(CameraUpdateFactory.newLatLng(list.get(0).getLatLgnBounds().getCenter()));
            LatLngBounds.Builder builder = new LatLngBounds.Builder();
            builder.include(currentLatLng);
            builder.include(Constants.POINT_DEST);
            LatLngBounds bounds = builder.build();
            mMap.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds, 50));
        }
        catch (Exception e)
        {
            Toast.makeText(MapsActivity.this, "EXCEPTION: Cannot parse routing response", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRoutingCancelled() {
        Toast.makeText(MapsActivity.this, "Routing Cancelled", Toast.LENGTH_SHORT).show();
    }


    public int CalculationByDistance(LatLng StartP, LatLng EndP) {
        int Radius=6371;//radius of earth in Km
        double lat1 = StartP.latitude;
        double lat2 = EndP.latitude;
        double lon1 = StartP.longitude;
        double lon2 = EndP.longitude;
        double dLat = Math.toRadians(lat2-lat1);
        double dLon = Math.toRadians(lon2-lon1);
        double a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                        Math.sin(dLon/2) * Math.sin(dLon/2);
        double c = 2 * Math.asin(Math.sqrt(a));
        double valueResult= Radius*c;
        double km=valueResult/1;
        DecimalFormat newFormat = new DecimalFormat("####");
        int kmInDec =  Integer.valueOf(newFormat.format(km));
        double meter=valueResult%1000;
        int  meterInDec= Integer.valueOf(newFormat.format(meter));
        Log.i("Radius Value",""+valueResult+"   KM  "+kmInDec+" Meter   "+meterInDec);

        return kmInDec;
    }

    private void showalertDialog(int distance) {

        AlertDialog alertDialog = new AlertDialog.Builder(MapsActivity.this).create();
        alertDialog.setTitle("Fare");
        alertDialog.setMessage(distance+" km "+ "Total Fare : "+distance * 5+" Rs");
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDialog.show();
    }

    public void Myalertdialog(String id,String location,int d){

        try {
            /*getInstance of dialog*/
            mydialog = new Dialog(this);
            mydialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            mydialog.setContentView(R.layout.dialog_details);

            tv_Stockiest_name = (TextView)mydialog.findViewById(R.id.Stockiest_name);
            user_location = (TextView)mydialog.findViewById(R.id.userlocation);
            cutImage = (ImageView)mydialog.findViewById(R.id.hideDialog);
            user_img = (ImageView)mydialog.findViewById(R.id.user_image);

            tv_distance_kms = (TextView)mydialog.findViewById(R.id.tv_distance);

            tv_Stockiest_name.setText(names[Integer.parseInt(id)]);
            user_location.setText(location);
            tv_distance_kms.setText(d +" kms away from your current location");
            user_img.setImageResource(logos[Integer.parseInt(id)]);

            cutImage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mydialog.dismiss();
                }
            });


        }
        catch (Exception e)
        {
            Log.i("error","eroro..!!"+ e.getMessage());
            e.printStackTrace();
        }
        mydialog.show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                //Permission Granted
                //Do your work here
                //Perform operations here only which requires permission

                startActivity(new Intent(MapsActivity.this,MapsActivity.class));

            }
        }
    }


    private String getDirectionsUrl(LatLng origin,LatLng dest){

        // Origin of route
        String str_origin = "origin="+origin.latitude+","+origin.longitude;

        // Destination of route
        String str_dest = "destination="+dest.latitude+","+dest.longitude;

        // Sensor enabled
        String sensor = "sensor=false";

        // Waypoints
        String waypoints = "";
        for(int i=2;i<markerPoints.size();i++){
            LatLng point  = (LatLng) markerPoints.get(i);
            if(i==2)
                waypoints = "waypoints=";
            waypoints += point.latitude + "," + point.longitude + "|";
        }


        // Building the parameters to the web service
        String parameters = str_origin+"&"+str_dest+"&"+sensor+"&"+waypoints;

        // Output format
        String output = "json";

        // Building the url to the web service
        String url = "https://maps.googleapis.com/maps/api/directions/"+output+"?"+parameters;


        return url;
    }

    /** A method to download json data from url */
    private String downloadUrl(String strUrl) throws IOException{
        String data = "";
        InputStream iStream = null;
        HttpURLConnection urlConnection = null;
        try{
            URL url = new URL(strUrl);

            // Creating an http connection to communicate with url
            urlConnection = (HttpURLConnection) url.openConnection();

            // Connecting to url
            urlConnection.connect();

            // Reading data from url
            iStream = urlConnection.getInputStream();

            BufferedReader br = new BufferedReader(new InputStreamReader(iStream));

            StringBuffer sb  = new StringBuffer();

            String line = "";
            while( ( line = br.readLine())  != null){
                sb.append(line);
            }

            data = sb.toString();

            br.close();

        }catch(Exception e){
            Log.d("Exception downloaded", e.toString());
        }finally{
            iStream.close();
            urlConnection.disconnect();
        }
        return data;
    }

    // Fetches data from url passed
    private class DownloadTask extends AsyncTask<String, Void, String> {

        // Downloading data in non-ui thread
        @Override
        protected String doInBackground(String... url) {

            // For storing data from web service
            String data = "";

            try{
                // Fetching the data from web service
                data = downloadUrl(url[0]);
            }catch(Exception e){
                Log.d("Background Task",e.toString());
            }
            return data;
        }

        // Executes in UI thread, after the execution of
        // doInBackground()
        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            ParserTask parserTask = new ParserTask();

            // Invokes the thread for parsing the JSON data
            parserTask.execute(result);

        }
    }

    /** A class to parse the Google Places in JSON format */
    private class ParserTask extends AsyncTask<String, Integer, List<List<HashMap<String,String>>> >{

        // Parsing the data in non-ui thread
        @Override
        protected List<List<HashMap<String, String>>> doInBackground(String... jsonData) {

            JSONObject jObject;
            List<List<HashMap<String, String>>> routes = null;

            try{
                jObject = new JSONObject(jsonData[0]);
                DirectionsJSONParser parser = new DirectionsJSONParser();

                // Starts parsing data
                routes = parser.parse(jObject);
            }catch(Exception e){
                e.printStackTrace();
            }
            return routes;
        }
        // Executes in UI thread, after the parsing process
        @Override
        protected void onPostExecute(List<List<HashMap<String, String>>> result) {



            try{
                Log.d("lineOptions Task---", String.valueOf(result));

                ArrayList<LatLng> points = null;
                PolylineOptions lineOptions = null;

                // Traversing through all the routes
                for(int i=0;i<result.size();i++){
                    points = new ArrayList<LatLng>();
                    lineOptions = new PolylineOptions();

                    // Fetching i-th route
                    List<HashMap<String, String>> path = result.get(i);

                    // Fetching all the points in i-th route
                    for(int j=0;j<path.size();j++){
                        HashMap<String,String> point = path.get(j);

                        double lat = Double.parseDouble(point.get("lat"));
                        double lng = Double.parseDouble(point.get("lng"));
                        LatLng position = new LatLng(lat, lng);

                        points.add(position);
                    }

                    // Adding all the points in the route to LineOptions
                    lineOptions.addAll(points);
                    lineOptions.width(2);
                    lineOptions.color(Color.RED);
                }
                Log.d("lineOptions Task---", String.valueOf(lineOptions));

                // Drawing polyline in the Google Map for the i-th route
                mMap.addPolyline(lineOptions);
            }
            catch (NullPointerException e)
            {
                e.printStackTrace();
            }

        }
    }
}

